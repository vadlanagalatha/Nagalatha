<?php 


$conn = mysqli_connect("localhost","root","Password!1","products");

?>