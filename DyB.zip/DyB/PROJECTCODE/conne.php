<?php
    $connection=mysqli_connect("localhost","root","Password!1","upload");
?>
